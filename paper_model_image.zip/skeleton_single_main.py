# visualize the activation of the feature map
import torch
from torch.utils.data import DataLoader
import torchvision.transforms as T
import matplotlib.pyplot as plt
import seaborn as sns
import shutil
from PIL import Image
#from data.samplers import RandomIdentitySampler
#from modeling.backbones.res50 import ResNet50
#from data.datasets import init_dataset, ImageDataset
import numpy as np
import math
import modeling_mask_algorithm as mask_method
import os.path as osp
import glob
import re


def test_collate_fn(batch):
    imgs, _, _, path = zip(*batch)
    return torch.stack(imgs, dim=0), path


def make_data_loader():
    # normalization的部分好像可以去掉?
    transforms = T.Compose([T.Resize([256, 128]), T.ToTensor(), T.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])])

    # 读取对应的数据集的加载方法
    dataset = init_dataset(('occluded-dukemtmc-reid'), root='./data')

    # 获取需要的数据集信息和变量
    num_classes = dataset.num_train_pids
    test_set = ImageDataset(dataset.train, transforms)      # transforms就是对获取到的数据进行进一步的操作，比如resize到网络的入口大小，或者转换成tensor的格式

    # create loader
    test_loader = DataLoader(test_set, batch_size=32, shuffle=False,
                             sampler=RandomIdentitySampler(dataset.train, 16, 4),
                             num_workers=8,
                             collate_fn=test_collate_fn)
    return test_loader, len(dataset.train), num_classes


def heatmap_seaborn(ori_path, feat, des_path):      # 原图的地址、特征、目标地址
    # create plot
    fig = plt.figure(figsize=(4, 4))

    ax0 = fig.add_subplot(121, title="Image")       # 1行2列的第1个区域
    ax0.imshow(Image.open(ori_path))
    plt.axis('off')

    # sum or mean
    ax1 = fig.add_subplot(122, title="Heatmap")      # 1行2列的第1个区域
    feat = torch.sum(feat, dim=0)
    feat = feat.cpu().detach().numpy()
    sns.heatmap(feat, xticklabels=False, yticklabels=False, center=None, cbar=False, square=True)

    name = ori_pth.split('\\')[-1].split('.')[0]
    save_path = des_path + name + ".jpg"

    # plt.subplots_adjust(wspace=-0.55)
    plt.show()
    fig.savefig(save_path)


def heatmap_seaborn2(img, feat, des_path):      # 原图的地址、特征、目标地址
    # create plot
    fig = plt.figure(figsize=(4, 4))

    ax0 = fig.add_subplot(121, title="Image")       # 1行2列的第1个区域
    ax0.imshow(img)
    plt.axis('off')

    # sum or mean
    ax1 = fig.add_subplot(122, title="Heatmap")      # 1行2列的第1个区域
    sns.heatmap(feat, xticklabels=False, yticklabels=False, center=None, cbar=False, square=True, cmap="GnBu")


    # plt.subplots_adjust(wspace=-0.55)
    plt.show()
    fig.savefig(des_path)

def process_dir(query_dir, query_pose_dir, query_pose_detection_vis_dir, output_dir):
    # get the all images path, put them into a list
    img_paths = glob.glob(osp.join(query_dir, '*.jpg'))
    dataset = []
    for img_path in img_paths:
        name = img_path.split('/')[-1].split('.')[0]
        name = name.split('\\')[-1]
        pose_path = query_pose_dir + '/' + name + '.npy'
        pose_vis_path = query_pose_detection_vis_dir + '/' + name + '_vis.jpg'
        output_path = output_dir + '/' + name + '.png'
        dataset.append((img_path, pose_path, pose_vis_path, output_path))
    return dataset


def read_keypoint(keypoint_path, img_shape):
    pose_info = np.load(keypoint_path, allow_pickle=True)
    # heatmap = torch.tensor(pose_info.item()['heatmap'], dtype=torch.float32)
    keypoints = pose_info.item()['keypoints']

    img_shape = np.array(img_shape)
    target_shape = np.array((16, 32))
    retio = target_shape / img_shape
    keypoints[:,:2] = keypoints[:,:2] * retio

    keypoints[:,[0, 1]] = keypoints[:,[1, 0]]

    return keypoints


def read_image(vis_path):
    vis_img = Image.open(vis_path)
    shape = vis_img.size
    img = vis_img.resize((100, 200))

    return img, shape

def process_predefined(keypoint_data):
    # 胳膊
    list = []
    list.append((keypoint_data[12], keypoint_data[13]))     # 头
    list.append((keypoint_data[2], keypoint_data[0]))       # 左上臂
    list.append((keypoint_data[2], keypoint_data[4]))       # 左下臂
    list.append((keypoint_data[3], keypoint_data[1]))       # 右上臂
    list.append((keypoint_data[3], keypoint_data[5]))       # 右下臂

    list.append((keypoint_data[8], keypoint_data[6]))       # 左大腿
    list.append((keypoint_data[8], keypoint_data[10]))      # 左小腿
    list.append((keypoint_data[9], keypoint_data[7]))       # 右大腿
    list.append((keypoint_data[9], keypoint_data[11]))      # 右小腿

    top_center = (keypoint_data[0] + keypoint_data[1]) / 2
    down_center = (keypoint_data[6] + keypoint_data[7]) / 2
    left_center = (keypoint_data[0] + keypoint_data[6]) / 2
    right_center = (keypoint_data[1] + keypoint_data[7]) / 2

    list.append((top_center, left_center))                  # 左上躯干
    list.append((top_center, right_center))                 # 右上躯干
    list.append((down_center, left_center))                 # 左下躯干
    list.append((down_center, right_center))                # 右下躯干
    list.append((top_center, down_center))                  # 整个躯干

    return list



if __name__ == "__main__":


    dataset_dir = 'occluded_duke_samples'
    query_dir = osp.join(dataset_dir, 'query')
    query_pose_dir = osp.join(dataset_dir, 'query_pose')
    query_pose_detection_vis_dir = osp.join(dataset_dir, 'query_vis_pose')
    output_dir = './output'
    dataset = process_dir(query_dir, query_pose_dir, query_pose_detection_vis_dir, output_dir)
    img_sample_path, pose_sample_path, pose_vis_sample_path, output_sample_path = dataset[0]    # 选取样本

    img, img_shape = read_image(pose_vis_sample_path)

    keypoint_data = read_keypoint(pose_sample_path, img_shape)
    pre_defined_skeleton = process_predefined(keypoint_data)

    point1_info, point2_info = pre_defined_skeleton[13]
    point1 = point1_info[:2]
    point2 = point2_info[:2]

    # point1 = np.array([16, 9])
    # point2 = np.array([22, 6])


    # 准备工作
    response_base_map = np.zeros((32, 16))
    point_center = ((point1 + point2) / 2)
    l_ao = math.sqrt((point1[0] - point2[0]) ** 2 + (point1[1] - point2[1]) ** 2) / 2
    vector_skeleton = np.array([point1[0] - point2[0], point1[1] - point2[1]])
    alpha = 0.9           # alpha越大，辐射范围越大
    gama = 1          # gama越大，越细

    response = mask_method.test5(response_base_map, point_center, l_ao, vector_skeleton, gama, alpha)

    # response[point1[0]][point1[1]] = 1.2
    # response[point2[0]][point2[1]] = 1.2

    heatmap_seaborn2(img, response, output_sample_path)
    print("Completed!")



    # ori_pth = "./skeleton.jpg"
    # des_pth = "./template_out.png"
    # point1 = [16, 9]
    # confidence1 = 0.8
    # # point2 = [26, 4]
    # point2 = [22, 6]
    # confidence2 = 0.8
    # r = 2.5

    # # 考虑中点因为置信度不同的便宜情况
    # point_center = [0, 0]
    # point_center[0] = (point1[0] + point2[0]) / 2
    # point_center[1] = (point1[1] + point2[1]) / 2
    # confidence = (confidence1 + confidence2) / 2
    # c_weight = confidence2 / (confidence1 + confidence2)
    # weighted_center = [0, 0]
    # weighted_center[0] = point1[0] + (point2[0] - point1[0]) * c_weight
    # weighted_center[1] = point1[1] + (point2[1] - point1[1]) * c_weight