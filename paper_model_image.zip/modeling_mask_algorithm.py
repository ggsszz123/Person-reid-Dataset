# encoding: utf-8
"""
@author:  Wangzijin
@contact: xdan_wzj@163.com
"""

import torch
from torch.utils.data import DataLoader
import torchvision.transforms as T
import matplotlib.pyplot as plt
import seaborn as sns
import shutil
from PIL import Image
#from data.samplers import RandomIdentitySampler
#from modeling.backbones.res50 import ResNet50
#from data.datasets import init_dataset, ImageDataset
import numpy as np
import math
import modeling_mask_algorithm as msk_method

def test1(response):

    for i in range(32):
        for j in range(16):
            response1[i][j] = confidence1 * math.exp(-((i - point1[0]) ** 2 + (j - point1[1]) ** 2) / (confidence1 * (r ** 2)))
            response2[i][j] = confidence2 * math.exp(-((i - point2[0]) ** 2 + (j - point2[1]) ** 2) / (confidence2 * (r ** 2)))
            response3[i][j] = confidence3 * math.exp(-((i - point3[0]) ** 2 + (j - point3[1]) ** 2) / (confidence3 * (r ** 2)))
    response = response1 + response2 + response3
    return response

def test2(response):

    for i in range(32):
        for j in range(16):
            response[i][j] = confidence1 * math.exp(-((i - point_center[0]) ** 2 + (j - point_center[1]) ** 2) / (confidence1 * (r_center ** 2)))
    return response

def test3(response):

    for i in range(32):
        for j in range(16):
            vec1 = np.array([i - point_center[0], j - point_center[1]])
            cos_sim = np.dot(vec1, vector_skeleton) / (np.linalg.norm(vec1) * np.linalg.norm(vector_skeleton))
            beta = abs(cos_sim) * alpha
            new_r = beta * r_center
            response[i][j] = math.exp(-((i - point_center[0]) ** 2 + (j - point_center[1]) ** 2) / (new_r ** 2))

    return response

def test4(response):

    for i in range(32):
        for j in range(16):
            vec1 = np.array([i - point_center[0], j - point_center[1]])
            cos_sim = np.dot(vec1, vector_skeleton) / (np.linalg.norm(vec1) * np.linalg.norm(vector_skeleton))
            beta = alpha * math.exp(gama * abs(cos_sim) - 1)
            new_r = beta * r_center
            response[i][j] = math.exp(-((i - point_center[0]) ** 2 + (j - point_center[1]) ** 2) / (new_r ** 2))

    return response

def test5(response_base_map, point_center, l_ao, vector_skeleton, gama, alpha):

    for i in range(32):
        for j in range(16):
            vec1 = np.array([i - point_center[0], j - point_center[1]])
            cos_sim = np.dot(vec1, vector_skeleton) / (np.linalg.norm(vec1) * np.linalg.norm(vector_skeleton))
            # cos_sim = cos_sim ** 2
            beta = math.exp(gama * (cos_sim ** 2 - 1)) * alpha
            # beta = math.exp(gama * (abs(cos_sim) - 1))

            new_r = beta * l_ao
            response_base_map[i][j] = math.exp(-((i - point_center[0]) ** 2 + (j - point_center[1]) ** 2) / (new_r ** 2))

    return response_base_map