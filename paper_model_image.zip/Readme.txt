环境：
	python3.7

关键依赖包：
	pytorch、seaborn、PIL、numpy、glob、math
	（其余的缺什么就pip install什么.......）

文件描述：
	occluded_duke_samples：duke数据集中的样本图像
	output：程序输出的目录
	modeling_mask_algorithm：计算单个骨骼mask的算法，一共写了5种，最后使用的是“test5”
	skeleton_single_main：单个骨骼mask运算并可视化的代码。
	skeleton_full_main：所有的骨骼mask预算并合并可视化的代码。

运行：
	配置好环境之后，命令行输入“python skeleton_full_main.py”